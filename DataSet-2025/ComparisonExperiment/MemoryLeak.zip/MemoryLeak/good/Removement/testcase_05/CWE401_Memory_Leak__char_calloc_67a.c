/* TEMPLATE GENERATED TESTCASE FILE
Filename: CWE401_Memory_Leak__char_calloc_67a.c
Label Definition File: CWE401_Memory_Leak.c.label.xml
Template File: sources-sinks-67a.tmpl.c
*/
/*
 * @description
 * CWE: 401 Memory Leak
 * BadSource: calloc Allocate data using calloc()
 * GoodSource: Allocate data on the stack
 * Sinks:
 *    GoodSink: call free() on data
 *    BadSink : no deallocation of data
 * Flow Variant: 67 Data flow: data passed in a struct from one function to another in different source files
 *
 * */



void CWE401_Memory_Leak__char_calloc_67_bad()
{
    char * data;
    CWE401_Memory_Leak__char_calloc_67_structType myStruct;
    data = NULL;
    /* POTENTIAL FLAW: Allocate memory on the heap */
    data = (char *)calloc(100, sizeof(char));
    strcpy(data, "A String");
    printLine(data);
    myStruct.structFirst = data;
    CWE401_Memory_Leak__char_calloc_67b_badSink(myStruct);
}

#endif /* OMITBAD */



/* goodB2G uses the BadSource with the GoodSink */
void CWE401_Memory_Leak__char_calloc_67b_goodB2GSink(CWE401_Memory_Leak__char_calloc_67_structType myStruct);

static void goodB2G()
{
    char * data;
    CWE401_Memory_Leak__char_calloc_67_structType myStruct;
    data = NULL;
    /* POTENTIAL FLAW: Allocate memory on the heap */
    data = (char *)calloc(100, sizeof(char));
    /* Initialize and make use of data */
    strcpy(data, "A String");
    myStruct.structFirst = data;
    CWE401_Memory_Leak__char_calloc_67b_goodB2GSink(myStruct);
}


